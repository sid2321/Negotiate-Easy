package com.example.admin.sdnegga;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

class SectionsPagerAdapter_seller extends FragmentPagerAdapter {
    public SectionsPagerAdapter_seller(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {

        switch (position) {
            case 0:

                OwnedFragment_Seller ownedFragment_seller = new OwnedFragment_Seller();
                return ownedFragment_seller;

            case 1:
                NegFragment_Seller negFragment_seller = new NegFragment_Seller();
                return negFragment_seller;
            case 2:

                RentedFragment_Seller rentedFragment_Seller_ = new RentedFragment_Seller();
                return rentedFragment_Seller_;

            default:
                return null;

        }

    }

    @Override
    public int getCount() {
        return 3;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {

        switch (position) {
            case 0:
                return "Owned";
            case 1:
                return "Negotiating";
            case 2:
                return "Rented";

            default:
                return null;
        }

    }
}
