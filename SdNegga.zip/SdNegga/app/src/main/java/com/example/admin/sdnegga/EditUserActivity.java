package com.example.admin.sdnegga;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class EditUserActivity extends AppCompatActivity {


    private EditText newName, newContact, newAddress;
    private FirebaseAuth mAuth;
    private FirebaseFirestore mFirestore;
    Button update;
    String finalName, finalContact, finalAddress;
    private ProgressDialog mRegProgress;
    private FirebaseUser mCurrentUser;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference usersRef=db.collection("Customer");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);

        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        final String current_id=mCurrentUser.getUid();

        newName = (EditText) findViewById(R.id.new_name);
        newContact = (EditText) findViewById(R.id.property_address);
        newAddress = (EditText) findViewById(R.id.new_address);

        mAuth = FirebaseAuth.getInstance();
        mFirestore = FirebaseFirestore.getInstance();
        mRegProgress = new ProgressDialog(this);

        newName.setText(getIntent().getExtras().getString("name"));
        newContact.setText(getIntent().getExtras().getString("contact"));
        newAddress.setText(getIntent().getExtras().getString("address"));

        update = (Button) findViewById(R.id.add_property_btn);

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finalName = newName.getText().toString();
                finalContact = newContact.getText().toString();
                finalAddress = newAddress.getText().toString();

                if(!TextUtils.isEmpty(finalName) && !TextUtils.isEmpty(finalContact) && !TextUtils.isEmpty(finalAddress)){

                    mRegProgress.setTitle("Updating User");
                    mRegProgress.setMessage("Please wait while we update your profile!");
                    mRegProgress.setCanceledOnTouchOutside(false);
                    mRegProgress.show();

                    //function to register user in firebase auth using email and password
                    update_user(finalName,finalContact,finalAddress,current_id);
                    // register_tenent(display_name,email,userid);
                }
                else
                {
                    Toast.makeText(EditUserActivity.this, "Required fields are empty", Toast.LENGTH_LONG).show();
                }







            }
        });
    }

    void update_user(String finalName,String finalContact, String finalAddress,String current_id){



        // creating custom document .storing AuthID to firestore table "Tenant"
        String final_name=finalName;
        String final_contact=finalContact;
        String final_address=finalAddress;

        usersRef.document(current_id)
                .update(
                        "Name", final_name,
                        "Contact",final_contact ,
                        "Address",final_address
                );

        Toast.makeText(EditUserActivity.this, "Your Profile has been updated",
                Toast.LENGTH_LONG).show();
        //Intent intent=new Intent(EditUserActivity.this,MainActivity.class);
        //startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);


    }

    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);

    }
}



















