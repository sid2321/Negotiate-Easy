package com.example.admin.sdnegga;

import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;

class SectionsPagerAdapter extends FragmentStatePagerAdapter {
    int mNumOfTabs;
    public SectionsPagerAdapter(FragmentManager fm, int count) {
        super(fm);
        mNumOfTabs = count;
    }

    @Override
    public int getCount() {
        return mNumOfTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position){
            case 0:
                AvailableFragment_Buyer availableFragmentBuyer = new AvailableFragment_Buyer();
                return availableFragmentBuyer;
            case 1:
                NegFragment_Buyer negFragmentBuyer = new NegFragment_Buyer();
                return negFragmentBuyer;
            case 2:
                BookedFragment_Buyer bookedFragmentBuyer = new BookedFragment_Buyer();
                return bookedFragmentBuyer;

                default:
                    return null;

        }

    }


    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        SpannableStringBuilder builder = new SpannableStringBuilder();

        switch (position){
            case 0:
               /* String avl ="Available";
                SpannableString redSpannable= new SpannableString(avl);
                redSpannable.setSpan(new ForegroundColorSpan(Color.BLACK), 0, avl.length(), 0);
                builder.append(redSpannable);*/
                return "Available";

            case 1:
                return "Negotiating";
            case 2:
                return "Booked";

                default:
                    return null;
        }

    }
}
