package com.example.admin.sdnegga;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class AddPropertyActivity extends AppCompatActivity {

    private FirebaseAuth mFirebaseAuth;
    private FirebaseFirestore mFirestore;
    private FirebaseUser mCurrentUser;

    private EditText property_name, property_address, property_description, property_b_price;
    private Button add_property_btn,imgbtn;
    private static final String FIRE_LOG = "Fire_Log";
    private String o_name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_property);

        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirestore = FirebaseFirestore.getInstance();


        property_name = (EditText) findViewById(R.id.property_name);
        property_address = (EditText) findViewById(R.id.property_address);
        property_description = (EditText) findViewById(R.id.property_description);
        property_b_price = (EditText) findViewById(R.id.property_b_price);

        add_property_btn = (Button) findViewById(R.id.add_property_btn);



        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_id = mCurrentUser.getUid();

      /*  mFirestore.collection("Customer").document(current_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                    DocumentSnapshot documentSnapshot=task.getResult();

                    if(documentSnapshot.exists() && documentSnapshot !=null) {


                        o_name = documentSnapshot.getString("Name");
                    }

                }else{
                    Log.d(FIRE_LOG,"Error: " + task.getException().getMessage());
                }
            }
        });*/






        add_property_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String p_name = property_name.getText().toString();
                String p_address = property_address.getText().toString();
                String p_description = property_description.getText().toString();
                String p_b_price = property_b_price.getText().toString();


                if(!TextUtils.isEmpty(p_name) && !TextUtils.isEmpty(p_address) && !TextUtils.isEmpty(p_description) && !TextUtils.isEmpty(p_b_price)) {
                    add_property(p_name, p_address, p_description, p_b_price, current_id);
                    Toast.makeText(AddPropertyActivity.this, "Real estate added successfully",
                            Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(AddPropertyActivity.this, MainActivity_Seller.class);
                    startActivity(intent);
                    finish();
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                }
                else
                {
                    Toast.makeText(AddPropertyActivity.this,"Please dont leave any fields Empty",Toast.LENGTH_LONG).show();
                }

            }


        });

        }
                private void add_property(String p_name, String p_address, String p_description, String p_b_price, String current_id){




                    Map<String,String> userMap = new HashMap<>();

                    userMap.put("Property_Name",p_name);
                    userMap.put("Property_Address",p_address);
                    userMap.put("Property_Description",p_description);
                    userMap.put("Property_Base_Price",p_b_price);
                    userMap.put("Property_Status","Not Rented");
                    userMap.put("Owner_id",current_id);
                    userMap.put("Customer_id","");
                    userMap.put("image","https://firebasestorage.googleapis.com/v0/b/sdnegga.appspot.com/o/property_images%2Fdownload.jpg?alt=media&token=6ea8a71b-8eab-4190-bd4d-747505dde386");
                   // userMap.put("Owner_name",o_name);


                    mFirestore.collection("Property").add(userMap);

                }

}


