package com.example.admin.sdnegga;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class UserImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_image);
    }
}
