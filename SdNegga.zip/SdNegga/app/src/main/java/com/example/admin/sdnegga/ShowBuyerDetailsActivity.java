package com.example.admin.sdnegga;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class ShowBuyerDetailsActivity extends AppCompatActivity {

    private static final String FIRE_LOG = "Fire_Log";
    private TextView mDisplayName;
    private TextView mDisplayContact;
    private TextView mDisplayEmail;
    private TextView mDisplayAddress;
    private CircleImageView mDisplayImage;

    private FirebaseUser mCurrentUser;

    private static final int GALLERY_PICK = 1;

    private StorageReference mImageStorage;
    // private String current_id;

    private ProgressDialog mProgressDialog;

    private FirebaseFirestore mFireStore = FirebaseFirestore.getInstance();
    private CollectionReference customerRef = mFireStore.collection("Customer");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_buyer_details);

        //mFireStore= FirebaseFirestore.getInstance();
        mDisplayName = (TextView) findViewById(R.id.buyer_display_name);
        mDisplayContact = (TextView) findViewById(R.id.buyer_display_contact);
        mDisplayEmail = (TextView) findViewById(R.id.buyer_display_email);
        mDisplayAddress = (TextView) findViewById(R.id.buyer_display_address);
        mDisplayImage = (CircleImageView) findViewById(R.id.buyer_image);


        final String current_id = getIntent().getExtras().getString("cid");

        //storage reference instance
        mImageStorage = FirebaseStorage.getInstance().getReference();


        mFireStore.collection("Customer").document(current_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot documentSnapshot = task.getResult();

                    if (documentSnapshot.exists() && documentSnapshot != null) {


                        String name = documentSnapshot.getString("Name");
                        String contact = documentSnapshot.getString("Contact");
                        String email = documentSnapshot.getString("Email");
                        String address = documentSnapshot.getString("Address");
                        final String image = documentSnapshot.getString("image");


                        Toast.makeText(ShowBuyerDetailsActivity.this, "image" + image, Toast.LENGTH_SHORT).show();


                        mDisplayName.setText(name);
                        mDisplayContact.setText(contact);
                        mDisplayEmail.setText(email);
                        mDisplayAddress.setText(address);

                        //retrieving and setting in circular image view
                        Picasso.with(ShowBuyerDetailsActivity.this).load(image).into(mDisplayImage);


                        mDisplayImage.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                Intent intent = new Intent(ShowBuyerDetailsActivity.this, zoom_user_image.class);
                                intent.putExtra("zoomimg", image);
                                startActivity(intent);
                                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                            }
                        });


                    }

                } else {
                    Log.d(FIRE_LOG, "Error: " + task.getException().getMessage());
                }
            }
        });
    }
}
