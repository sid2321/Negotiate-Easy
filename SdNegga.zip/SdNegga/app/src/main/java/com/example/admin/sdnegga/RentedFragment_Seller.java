package com.example.admin.sdnegga;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import static android.content.ContentValues.TAG;


/**
 * A simple {@link Fragment} subclass.
 *
 */




public class RentedFragment_Seller extends Fragment {



    private FirebaseUser mCurrentUser;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference propertiesRef=db.collection("Property");
    private CollectionReference usersRef=db.collection("Customer");
    private static final String FIRE_LOG = "Fire_Log";









    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {








        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_id = mCurrentUser.getUid();

        final View rootView = inflater.inflate(R.layout.fragment_rented_seller, container, false);


        final LinearLayout property_list=(LinearLayout) rootView.findViewById(R.id.rented_list_seller);


        // matching ownerID(current_id) of the current logged in user to the OwnerID(Owner_id) in the Property table .
        propertiesRef.
                whereEqualTo("Property_Status","Rented").
                get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {



                for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){

                    Property property=documentSnapshot.toObject(Property.class);
                    String owner_id=property.getOwner_id();

                    if(owner_id.equals(current_id)) {


                        //getting ID(document) of Property which are owned by current logged in user
                        final String property_id = documentSnapshot.getId();

                        String name = property.getProperty_Name();
                        String address = property.getProperty_Address();
                        String desc = property.getProperty_Description();
                        String price = property.getProperty_Base_Price();
                        // String owner=property.getOwner_name();
                        String status = property.getProperty_Status();

                        String customer_id = property.getCustomer_id();


                        final View Card = inflater.inflate(R.layout.activity_property_rented_card, container, false);
                        final TextView p_id = (TextView) Card.findViewById(R.id.p_id);
                        final TextView p_name = (TextView) Card.findViewById(R.id.p_name);
                        final TextView p_address = (TextView) Card.findViewById(R.id.p_address);
                        final TextView p_desc = (TextView) Card.findViewById(R.id.p_desc);
                        final TextView p_price = (TextView) Card.findViewById(R.id.p_price);
                        final TextView p_owner = (TextView) Card.findViewById(R.id.p_owner);
                        final TextView p_status = (TextView) Card.findViewById(R.id.p_status);
                        final TextView p_customer = (TextView) Card.findViewById(R.id.p_customer);
                        final Button viewbtn = (Button)Card.findViewById(R.id.img_button_rented) ;
                        final Button buyer_details=(Button)Card.findViewById(R.id.buyer_details);


                        final String image = documentSnapshot.getString("image");

                        usersRef.document(current_id).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task <DocumentSnapshot> task) {
                                if (task.isSuccessful()) {
                                    DocumentSnapshot documentSnapshot = task.getResult();

                                    if (documentSnapshot.exists() && documentSnapshot != null) {


                                        p_owner.setText(documentSnapshot.getString("Name"));

                                    }

                                } else {
                                    Log.d(FIRE_LOG, "Error: " + task.getException().getMessage());
                                }
                            }
                        });

                        final String cust_id = property.getCustomer_id();

                        if (cust_id != "")

                        {

                            usersRef.document(cust_id).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task <DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot documentSnapshot = task.getResult();

                                        if (documentSnapshot.exists() && documentSnapshot != null) {


                                            p_customer.setText(documentSnapshot.getString("Name"));

                                        }

                                    } else {
                                        Log.d(FIRE_LOG, "Error: " + task.getException().getMessage());
                                    }
                                }
                            });

                        } else {
                            p_customer.setVisibility(View.INVISIBLE);
                        }


                        p_id.setText(property_id);
                        p_name.setText(name);
                        p_address.setText(address);
                        p_desc.setText(desc);
                        p_price.setText(price);
                        p_status.setText(status);


                        property_list.addView(Card);

                        viewbtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                //retrieve image

                                Intent intent= new Intent(getContext(),zoom_user_image.class);
                                intent.putExtra("zoomimg",image);
                                startActivity(intent);
                                //overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                            }
                        });

                        buyer_details.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(getContext(), ShowBuyerDetailsActivity.class);
                                intent.putExtra("cid", cust_id);
                                startActivity(intent);


                            }


                        });


                    }





                }







            }
        });






        return rootView;












    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            // Refresh your fragment here
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
            Log.i("IsRefresh", "Yes");
        }
    }




}
