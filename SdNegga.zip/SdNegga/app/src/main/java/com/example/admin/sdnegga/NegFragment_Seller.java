package com.example.admin.sdnegga;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;


/**
 * A simple {@link Fragment} subclass.
 */
public class NegFragment_Seller extends Fragment {


    private FirebaseUser mCurrentUser;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference negotiateref = db.collection("Negotiate");
    private CollectionReference propertiesRef=db.collection("Property");

    private String mCustomerid;
    private String mPropertyid;

    private String mPropertyname,mPropertydesc,mPropertyprice,mPropertyaddr;
    private String mCustomername,mCustomeraddr,mCustomercontact;


    public NegFragment_Seller() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {


        // Inflate the layout for this fragment

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_id = mCurrentUser.getUid();

        final View rootView = inflater.inflate(R.layout.fragment_neg_seller, container, false);

        final LinearLayout neg_list_seller=(LinearLayout) rootView.findViewById(R.id.neg_list_seller);


        negotiateref.whereEqualTo("Neg_status","Negotiating").
                get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {



                for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){



                    Negotiate negotiate=documentSnapshot.toObject(Negotiate.class);
                    final String neg_id=documentSnapshot.getId();


                    final String sellerid = negotiate.getSellerID();


                    if(current_id.equals(sellerid)){

                        final View Card = inflater.inflate(R.layout.activity_seller_negotiate_list, container, false);
                       // String mstatus = negotiate.getPropertyID();
                        String mname=negotiate.getProperty_Name();
                        //final Button neg=(Button)Card.findViewById(R.id.neg_start);

                        mCustomerid = negotiate.getCustomerID();
                        mPropertyid = negotiate.getPropertyID();
                        final TextView padress = (TextView) Card.findViewById(R.id.p_address);
                        final TextView pname=(TextView)Card.findViewById(R.id.pr_name);
                        final TextView pdesc=(TextView)Card.findViewById(R.id.p_desc);
                        final TextView pprice=(TextView)Card.findViewById(R.id.p_price);
                        final Button buyer_details=(Button)Card.findViewById(R.id.buyer_details);

                        final TextView custname=(TextView)Card.findViewById(R.id.customer);
                        final TextView custcontact=(TextView)Card.findViewById(R.id.customercontact);

                        final Button dealbtn=(Button)Card.findViewById(R.id.deal_btn);
                       // status.setText(mstatus);
                       // pname.setText(mCustomerid);
                        //padress.setText(mPropertyid);
                        //pdesc.setText(sellerid);

                        //getting information about the properties owned by current user for which negotiation is happeining

                       db.collection("Property").document(mPropertyid).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                           @Override
                           public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                               if(task.isSuccessful()){
                                   DocumentSnapshot documentSnapshot=task.getResult();

                                   if(documentSnapshot.exists() && documentSnapshot !=null) {


                                       mPropertyname = documentSnapshot.getString("Property_Name");
                                       mPropertydesc = documentSnapshot.getString("Property_Description");
                                       mPropertyprice= documentSnapshot.getString("Property_Base_Price");
                                       mPropertyaddr = documentSnapshot.getString("Property_Address");

                                       pname.setText(mPropertyname);
                                       pdesc.setText(mPropertydesc);
                                       padress.setText(mPropertyaddr);
                                       pprice.setText(mPropertyprice);



                                   }

                               }

                           }
                       });

                       //retrieving details of customer who is negotiating with current logged in user

                       db.collection("Customer").document(mCustomerid).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                           @Override
                           public void onComplete(@NonNull Task <DocumentSnapshot> task) {

                               if(task.isSuccessful()){
                                   DocumentSnapshot documentSnapshot=task.getResult();

                                   if(documentSnapshot.exists() && documentSnapshot !=null) {


                                       mCustomername = documentSnapshot.getString("Name");
                                       mCustomeraddr = documentSnapshot.getString("Address");
                                       mCustomercontact = documentSnapshot.getString("Contact");

                                      custname.setText(mCustomername);
                                      custcontact.setText(mCustomercontact);



                                   }

                               }

                           }
                       });




                        neg_list_seller.addView(Card);

                        dealbtn.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                Intent intent = new Intent(getContext(),DealActivity.class);
                                intent.putExtra("sellerid",sellerid);
                                intent.putExtra("custid",mCustomerid);
                                intent.putExtra("propid",mPropertyid);
                                intent.putExtra("negid",neg_id);
                                startActivity(intent);

                            }
                        });

                        buyer_details.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent intent = new Intent(getContext(), ShowBuyerDetailsActivity.class);
                                intent.putExtra("cid", mCustomerid);
                                startActivity(intent);


                            }


                        });

                    }



                }










            }
        });










        return rootView;



    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
            Log.i("IsRefresh", "Yes");
        }
    }

}
