package com.example.admin.sdnegga;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.theartofdev.edmodo.cropper.CropImage;

public class EditpropertyActivity extends AppCompatActivity {

    EditText new_p_name,new_p_address,new_p_desc,new_p_price;
    TextView p_id;
    Button update_property;

    private FirebaseUser mCurrentUser;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference propertiesRef=db.collection("Property");
    private Button imgbtn;
    private static final int GALLERY_PICK = 1;
    private StorageReference mImageStorage;
    private ProgressDialog mProgressDialog;
    private FirebaseFirestore mFireStore=FirebaseFirestore.getInstance();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editproperty);

        //getting the instance
        mImageStorage = FirebaseStorage.getInstance().getReference();


        new_p_name=(EditText)findViewById(R.id.n_p_name);
        new_p_address=(EditText)findViewById(R.id.n_p_address);
        new_p_desc=(EditText)findViewById(R.id.n_p_desc);
        new_p_price=(EditText)findViewById(R.id.n_p_price);
        p_id=(TextView)findViewById(R.id.p_id);
        imgbtn=(Button)findViewById(R.id.edit_prop_imgbtn);

        update_property=(Button)findViewById(R.id.update_property);

        new_p_name.setText(getIntent().getExtras().getString("pname"));
        new_p_address.setText(getIntent().getExtras().getString("paddress"));
        new_p_desc.setText(getIntent().getExtras().getString("pdesc"));
        new_p_price.setText(getIntent().getExtras().getString("pprice"));
        p_id.setText(getIntent().getExtras().getString("id"));

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_id = mCurrentUser.getUid();

        final String pid=p_id.getText().toString();



        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryintent = new Intent();
                galleryintent.setType("image/*");
                galleryintent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(galleryintent,"Select image"),GALLERY_PICK);
            }
        });

        update_property.setOnClickListener(new View.OnClickListener() {
              @Override
            public void onClick(View v) {

                  String final_name=new_p_name.getText().toString();
                  String final_address=new_p_address.getText().toString();
                  String final_desc=new_p_desc.getText().toString();
                  String final_price=new_p_price.getText().toString();

                  if(!TextUtils.isEmpty(final_name) && !TextUtils.isEmpty(final_address) && !TextUtils.isEmpty(final_desc) && !TextUtils.isEmpty(final_price)) {

                      propertiesRef.document(pid)
                              .update(
                                      "Property_Name", final_name,
                                      "Property_Address", final_address,
                                      "Property_Description", final_desc,
                                      "Property_Base_Price", final_price
                              );

                      Toast.makeText(EditpropertyActivity.this, "Property Updated successfully",
                              Toast.LENGTH_LONG).show();
//                  Intent intent=new Intent(EditpropertyActivity.this,MainActivity_Seller.class);
//                  startActivity(intent);
                      finish();

                      overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);


                  }
                  else
                  {
                      Toast.makeText(EditpropertyActivity.this,"Required fields are empty",Toast.LENGTH_LONG).show();
                  }









            }
        });








    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @android.support.annotation.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        p_id.setText(getIntent().getExtras().getString("id"));
        final String pid2=p_id.getText().toString();

       // Toast.makeText(EditpropertyActivity.this,pid2,Toast.LENGTH_LONG).show();

        if(requestCode == GALLERY_PICK && resultCode == RESULT_OK){
            final Uri imageurl = data.getData();

            // start cropping activity for pre-acquired image saved on the device
            CropImage.activity(imageurl)
                    .setAspectRatio(1,1)
                    .start(this);

            // Toast.makeText(SettingsActivity.this,imageurl,Toast.LENGTH_LONG).show();
        }


        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                mProgressDialog = new ProgressDialog(EditpropertyActivity.this);
                mProgressDialog.setTitle("Uploading image");
                mProgressDialog.setMessage("Please wait, this will take few seconds");
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.show();

                final Uri resultUri = result.getUri();





                final StorageReference filepath = mImageStorage.child("property_images").child(pid2 + ".jpg");

                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {

                        if(task.isSuccessful()){
                            mProgressDialog.hide();
                            //String download_url = task.getResult().getStorage().getDownloadUrl().toString();

                            final String current_id4=mCurrentUser.getUid();
                            mImageStorage.child("property_images").child(pid2 + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener <Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String  download_url= uri.toString();
                                    //String current_id3 = mCurrentUser.getUid();
                                    Toast.makeText(EditpropertyActivity.this,"storing image ",Toast.LENGTH_LONG).show();

                                    propertiesRef.document(pid2)
                                            .update(
                                                    "image", download_url
                                            );

                                    Toast.makeText(EditpropertyActivity.this,"Image Photo Changed Successfully",Toast.LENGTH_LONG).show();
                                    startActivity(getIntent());
                                    finish();
                                    overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);




                                }


                            });








                        }
                        else{
                            mProgressDialog.dismiss();
                            Toast.makeText(EditpropertyActivity.this,"Failed saving image",Toast.LENGTH_LONG).show();

                        }

                    }
                });
            }

            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }








    }
}
