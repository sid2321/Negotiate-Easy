package com.example.admin.sdnegga;

import android.app.ProgressDialog;
import android.content.Intent;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import android.support.v7.widget.Toolbar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {
    private TextInputLayout mDisplayName;
    private TextInputLayout mEmail;
    private TextInputLayout mPassword,mPasswword_confirm;
    private Button mCreatebtn;
    private FirebaseAuth mAuth;
    private TextView logged_user;
    private Toolbar mToolbar;
    private String userid;
    private TextView redirect_to_login;

    private ProgressDialog mRegProgress;
    private FirebaseFirestore mFirestore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mToolbar = (Toolbar) findViewById(R.id.register_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setTitle("Create Account");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mRegProgress = new ProgressDialog(this);


        mAuth = FirebaseAuth.getInstance();
        mFirestore = FirebaseFirestore.getInstance();

        mDisplayName = (TextInputLayout) findViewById(R.id.reg_display_name);
        mEmail = (TextInputLayout) findViewById(R.id.login_email);
        mPassword = (TextInputLayout) findViewById(R.id.login_password);
        mPasswword_confirm = (TextInputLayout) findViewById(R.id.login_confirm_password);

        mCreatebtn = (Button) findViewById(R.id.reg_create_btn);
        redirect_to_login = (TextView) findViewById(R.id.redirect_to_login);


        redirect_to_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            }
        });


        mCreatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String display_name = mDisplayName.getEditText().getText().toString();
                String email = mEmail.getEditText().getText().toString();
                String password = mPassword.getEditText().getText().toString();
                String confirm=mPasswword_confirm.getEditText().getText().toString();

                if (!TextUtils.isEmpty(display_name) && !TextUtils.isEmpty(email) && !TextUtils.isEmpty(password) && !TextUtils.isEmpty(confirm)){

                    if(confirm.equals(password))
                    {

                        mRegProgress.setTitle("Registering User");
                        mRegProgress.setMessage("Please wait while we register you!");
                        mRegProgress.setCanceledOnTouchOutside(false);
                        mRegProgress.show();

                        //function to register user in firebase auth using email and password
                        register_user(display_name, email, password);
                        // register_tenent(display_name,email,userid);
                    }
                    else
                    {
                        Toast.makeText(RegisterActivity.this, "Passwords dont match", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText(RegisterActivity.this, "Some Required Fields are empty", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void register_customer(String display_name, String email, String userid) {

        Map <String, String> userMap = new HashMap <>();
        userMap.put("Name", display_name);
        userMap.put("Contact", "");
        userMap.put("Address", "");
        userMap.put("Email", email);
        userMap.put("image", "https://firebasestorage.googleapis.com/v0/b/sdnegga.appspot.com/o/profile_images%2Fdefaultimage.png?alt=media&token=65650a58-3974-4eaf-91d9-05fd721214b0");

        // userMap.put("id",userid);


        // creating custom document .storing AuthID to firestore table "Tenant"
        mFirestore.collection("Customer").document(userid).set(userMap).addOnSuccessListener(new OnSuccessListener <Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(RegisterActivity.this, "User Registered Succesfully",
                        Toast.LENGTH_LONG).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(RegisterActivity.this, "Registration Failed",
                        Toast.LENGTH_LONG).show();
            }
        });

      /*  mFirestore.collection("Tenant").add(userMap).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
            @Override
            public void onSuccess(DocumentReference documentReference) {
                Toast.makeText(RegisterActivity.this, "You have been succesfully registered",
                        Toast.LENGTH_LONG).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });*/


    }

    private void register_user(final String display_name, final String email, final String password) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener <AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task <AuthResult> task) {

                        if (task.isSuccessful()) {

                            // Sign in success, update UI with the signed-in user's information
                            mRegProgress.dismiss();



                            Intent mainintent = new Intent(RegisterActivity.this,LoginActivity.class);
                            mainintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                            //getting the current userID from firebase auth
                            FirebaseUser CurrentUser = FirebaseAuth.getInstance().getCurrentUser();
                            if (CurrentUser != null) {
                                userid = CurrentUser.getUid();
                            }

                            //uncomment this line for email verification
                            sendEmailVerification();
                            register_customer(display_name,email,userid);

                            //displaying name on new intent
                            startActivity(mainintent);

                            finish();

                            //function to save userdata in firestore


                            //displaying name on new intent


                            //function to save userdata in firestore









                        } else {
                            // If sign in fails, display a message to the user.

                            mRegProgress.hide();
                            Toast.makeText(RegisterActivity.this, "Registration Failed, try again later!",
                                    Toast.LENGTH_LONG).show();

                        }

                        // ...
                    }
                });


    }

    private void sendEmailVerification()
    {
        FirebaseUser firebaseUser=mAuth.getCurrentUser();

        if(userid!=null)
        {
            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener <Void>() {
                @Override
                public void onComplete(@NonNull Task <Void> task) {

                    if(task.isSuccessful()){
                        Toast.makeText(RegisterActivity.this, "User Registered Succesfully, Please verify Email to log in(Verification sent to registered email)", Toast.LENGTH_SHORT).show();
                        mAuth.signOut();
                        finish();
                        startActivity(new Intent(RegisterActivity.this,LoginActivity.class));
                    }
                    else
                    {
                        Toast.makeText(RegisterActivity.this,"Registration Failed, try again later!",Toast.LENGTH_SHORT).show();
                    }
                }
            });


        }

    }



}

