package com.example.admin.sdnegga;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SellerNegotiateListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_negotiate_list);
    }
}
