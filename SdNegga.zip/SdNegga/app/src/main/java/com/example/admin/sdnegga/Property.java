package com.example.admin.sdnegga;

public class Property {

    private String Property_Name;
    private String Property_Address;
    private String Property_Description;
    private String Property_Base_Price;
    private String Property_Status;
    private String Owner_id;
    private String Customer_id;

    public Property() {
    }

    public Property(String property_Name, String property_Address, String property_Description, String property_Base_Price,String property_status, String owner_id, String customer_id) {
        Property_Name = property_Name;
        Property_Address = property_Address;
        Property_Description = property_Description;
        Property_Base_Price = property_Base_Price;
        Property_Status=property_status;
        Owner_id=owner_id;
        Customer_id=customer_id;
    }

    public String getProperty_Name() {
        return Property_Name;
    }

    public void setProperty_Name(String property_Name) {
        Property_Name = property_Name;
    }

    public String getProperty_Address() {
        return Property_Address;
    }

    public void setProperty_Address(String property_Address) {
        Property_Address = property_Address;
    }

    public String getProperty_Description() {
        return Property_Description;
    }

    public void setProperty_Description(String property_Description) {
        Property_Description = property_Description;
    }

    public String getProperty_Base_Price() {
        return Property_Base_Price;
    }

    public void setProperty_Base_Price(String property_Base_Price) {
        Property_Base_Price = property_Base_Price;
    }


    public String getProperty_Status() {
        return Property_Status;
    }

    public void setProperty_Status(String property_Status) {
        Property_Status = property_Status;
    }


    public String getOwner_id() {
        return Owner_id;
    }

    public void setOwner_id(String owner_id) {
        Owner_id = owner_id;
    }

    public String getCustomer_id() {
        return Customer_id;
    }

    public void setCustomer_id(String customer_id) {
        Customer_id = customer_id;
    }
}
