package com.example.admin.sdnegga;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import javax.annotation.Nullable;

import de.hdodenhof.circleimageview.CircleImageView;
import io.grpc.Context;

public class SettingsActivity extends AppCompatActivity{

    private static final String FIRE_LOG = "Fire_Log";
    private TextView mDisplayName;
    private TextView mDisplayContact;
    private TextView mDisplayEmail;
    private TextView mDisplayAddress;
    private CircleImageView mDisplayImage;

    //private FirebaseFirestore mFireStore;

    private DatabaseReference mUserDatabase;

    private FirebaseUser mCurrentUser;

    private Button editInfo,upload_img;
    private ImageView delete_image;

    private static final int GALLERY_PICK = 1;

    private StorageReference mImageStorage;
   // private String current_id;

    private ProgressDialog mProgressDialog;

    private FirebaseFirestore mFireStore=FirebaseFirestore.getInstance();
    private CollectionReference customerRef=mFireStore.collection("Customer");





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //mFireStore= FirebaseFirestore.getInstance();
        mDisplayName=(TextView)findViewById(R.id.settings_display_name);
        mDisplayContact=(TextView)findViewById(R.id.settings_display_contact);
        mDisplayEmail=(TextView)findViewById(R.id.settings_display_email);
        mDisplayAddress=(TextView)findViewById(R.id.settings_display_address);
        mDisplayImage=(CircleImageView) findViewById(R.id.settings_image);

        editInfo=(Button)findViewById(R.id.editInfo);
        upload_img=(Button)findViewById(R.id.settings_image_btn);
        delete_image=(ImageView)findViewById(R.id.delete_image);

        mCurrentUser= FirebaseAuth.getInstance().getCurrentUser();
        final String current_id=mCurrentUser.getUid();

        //storage reference instance
        mImageStorage = FirebaseStorage.getInstance().getReference();







        mFireStore.collection("Customer").document(current_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.isSuccessful()){
                        DocumentSnapshot documentSnapshot=task.getResult();

                        if(documentSnapshot.exists() && documentSnapshot !=null) {


                            String name = documentSnapshot.getString("Name");
                            String contact = documentSnapshot.getString("Contact");
                            String email = documentSnapshot.getString("Email");
                            String address = documentSnapshot.getString("Address");
                            final String image = documentSnapshot.getString("image");


                            Toast.makeText(SettingsActivity.this, "image"+image, Toast.LENGTH_SHORT).show();


                            mDisplayName.setText(name);
                            mDisplayContact.setText(contact);
                            mDisplayEmail.setText(email);
                            mDisplayAddress.setText(address);

                            //retrieving and setting in circular image view
                            Picasso.with(SettingsActivity.this).load(image).into(mDisplayImage);


                            mDisplayImage.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    Intent intent= new Intent(SettingsActivity.this,zoom_user_image.class);
                                    intent.putExtra("zoomimg",image);
                                    startActivity(intent);
                                    overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                                }
                            });





                        }

                    }else{
                        Log.d(FIRE_LOG,"Error: " + task.getException().getMessage());
                }
            }
        });




        editInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(SettingsActivity.this,EditUserActivity.class);
                intent.putExtra("name",mDisplayName.getText().toString());
                intent.putExtra("contact",mDisplayContact.getText().toString());
                intent.putExtra("address",mDisplayAddress.getText().toString());
                startActivity(intent);
                finish();
                overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);




            }
        });




      /*  upload_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                
            }
        });*/

      //image button onclick function
        upload_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // code to choose actions such as gallery,photos,drive etc
                Intent galleryintent = new Intent();
                galleryintent.setType("image/*");
                galleryintent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(galleryintent,"Select image"),GALLERY_PICK);

               /* // start picker to get image for cropping and then use the image in cropping activity
                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .start(SettingsActivity.this);*/
            }
        });

        delete_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);
                builder.setMessage("Remove Image ??");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {




                                customerRef.document(current_id)
                                        .update(
                                                "image", "https://firebasestorage.googleapis.com/v0/b/sdnegga.appspot.com/o/profile_images%2Fdefaultimage.png?alt=media&token=65650a58-3974-4eaf-91d9-05fd721214b0"
                                        );

                                Toast.makeText(SettingsActivity.this, "Removed Photo successfully",
                                        Toast.LENGTH_LONG).show();
                                startActivity(getIntent());
                                finish();
                        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);













                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        dialogInterface.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();














            }
        });







    }




    // this function purely stores image in the storage as well as in the database ,
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @android.support.annotation.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == GALLERY_PICK && resultCode == RESULT_OK){
            final Uri imageurl = data.getData();

            // start cropping activity for pre-acquired image saved on the device
            CropImage.activity(imageurl)
                    .setAspectRatio(1,1)
                    .start(this);

           Toast.makeText(SettingsActivity.this,imageurl.toString(),Toast.LENGTH_LONG).show();
        }


        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if (resultCode == RESULT_OK) {

                mProgressDialog = new ProgressDialog(SettingsActivity.this);
                mProgressDialog.setTitle("Uploading image");
                mProgressDialog.setMessage("Please wait, this will take few seconds");
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.show();

                final Uri resultUri = result.getUri();

                String current_id2 = mCurrentUser.getUid();




                final StorageReference filepath = mImageStorage.child("profile_images").child(current_id2 + ".jpg");

                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener <UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task <UploadTask.TaskSnapshot> task) {

                        if(task.isSuccessful()){
                            mProgressDialog.hide();
                            //String download_url = task.getResult().getStorage().getDownloadUrl().toString();

                            final String current_id4=mCurrentUser.getUid();
                            mImageStorage.child("profile_images").child(current_id4 + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener <Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                  String  download_url= uri.toString();
                                    String current_id3 = mCurrentUser.getUid();

                                    customerRef.document(current_id3)
                                            .update(
                                                    "image", download_url
                                            );

                                    Toast.makeText(SettingsActivity.this,"Profile Photo Changed Successfully",Toast.LENGTH_LONG).show();
                                    startActivity(getIntent());
                                    finish();
                                    overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);




                                }


                            });








                        }
                        else{
                            mProgressDialog.dismiss();
                            Toast.makeText(SettingsActivity.this,"Failed saving image",Toast.LENGTH_LONG).show();

                        }

                    }
                });
            }

            else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
            }
        }








    }
    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
    }


}
