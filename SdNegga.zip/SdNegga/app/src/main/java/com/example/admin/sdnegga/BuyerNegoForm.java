package com.example.admin.sdnegga;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;
import java.util.zip.Inflater;

public class BuyerNegoForm extends AppCompatActivity {


    FirebaseFirestore mFirestore;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference propertiesRef = db.collection("Property");
    private CollectionReference questionsRef = db.collection("Questions");
    private CollectionReference negRef = db.collection("Negotiate");

    Button start_neg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_nego_form);



        final TextView mpid=(TextView)findViewById(R.id.getpid);
        final TextView moid=(TextView)findViewById(R.id.getoid);
        final TextView mcid=(TextView)findViewById(R.id.getcid);

        final CheckBox q1=(CheckBox)findViewById(R.id.q1);
        final CheckBox q2=(CheckBox)findViewById(R.id.q2);
        final CheckBox q3=(CheckBox)findViewById(R.id.q3);




        mpid.setText(getIntent().getExtras().getString("pid"));
        moid.setText(getIntent().getExtras().getString("oid"));
        mcid.setText(getIntent().getExtras().getString("cid"));

        mFirestore = FirebaseFirestore.getInstance();
        start_neg=(Button)findViewById(R.id.StartNeg);

        final LayoutInflater inflator = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final LinearLayout questions_list = (LinearLayout) findViewById(R.id.questions_list_choose);


        questionsRef.document("Question1").
                get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

                q1.setText(documentSnapshot.getString("Question"));




            }
        });

        questionsRef.document("Question2").
                get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

                q2.setText(documentSnapshot.getString("Question"));



            }
        });

        questionsRef.document("Question3").
                get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {

                q3.setText(documentSnapshot.getString("Question"));



            }
        });

        //copy above line if more questions



        start_neg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String,String> userMap = new HashMap<>();

                String cid=mcid.getText().toString();
                String pid=mpid.getText().toString();
                String oid=moid.getText().toString();

                userMap.put("CustomerID",cid);
                userMap.put("PropertyID",pid);
                userMap.put("SellerID",oid);
                userMap.put("seller_status","");
                userMap.put("buyer_status","");
                userMap.put("Neg_status","Negotiating");
                userMap.put("hasClicked_buyer","");
                userMap.put("hasClicked_seller","");
                // userMap.put("Owner_name",o_name);


              negRef.document(pid+cid+oid).set(userMap);




                Map<String,String> qMap = new HashMap<>();
                qMap.put("buyerans","");
                qMap.put("sellerans","");



                if(q1.isChecked()) {
                    negRef.document(pid+cid+oid).collection("final_questions").document("Question1").set(qMap);
                }

                if(q2.isChecked()) {
                    negRef.document(pid+cid+oid).collection("final_questions").document("Question2").set(qMap);
                }

                if(q3.isChecked()) {
                    negRef.document(pid+cid+oid).collection("final_questions").document("Question3").set(qMap);
                }







                propertiesRef.document(pid)
                        .update(
                                "Property_Status", "Negotiating"
                        );


                Toast.makeText(BuyerNegoForm.this, "Started Negotiation", Toast.LENGTH_SHORT).show();
                Intent back2main=new Intent(BuyerNegoForm.this,MainActivity.class);
                startActivity(back2main);
                finish();
                overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);





            }
        });








    }
}




















//        askbtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                if(quest1.isChecked()) {
//
//                   q1 = quest1.getText().toString();
//                    //mtest.setText(q1);
//
//                }
//                else{
//                    q1=null;
//                }
//                if(quest2.isChecked()){
//                   q2 = quest2.getText().toString();
//                    //mtest2.setText(q2);
//
//                }
//                else{
//                    q2=null;
//                }
//
//
//
//                saveQuestionstoDb(propid,ownerid,custid,q1,q2);
//
//
//                propertiesRef.document(propid)
//                        .update(
//                                "Property_Status", "Negotiating"
//                        );
//
//                sendback();
//            }
//        });
//
//    }
//
//    private void sendback() {
//
//        Intent intent=new Intent(BuyerNegoForm.this,MainActivity.class);
//        startActivity(intent);
//
//    }
//
//    private void saveQuestionstoDb(final String propid,final String ownerid, final String custid,String q1,String q2) {
//
//        Map<String,String> userMap = new HashMap<>();
//        userMap.put("PropertyID",propid);
//        userMap.put("SellerID",ownerid);
//        userMap.put("CustomerID",custid);
//        userMap.put("How Far is the school?",q1);
//        userMap.put("Property has master bedrooms ?",q2);
//
//        //saving data with auto generating ID (document)
//        mFirestore.collection("Negotiate").document().set(userMap).addOnSuccessListener(new OnSuccessListener<Void>() {
//            @Override
//            public void onSuccess(Void aVoid) {
//                Toast.makeText(BuyerNegoForm.this, "Request for negotiate sent successfully",
//                        Toast.LENGTH_LONG).show();
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(BuyerNegoForm.this, "Failed to send request",
//                        Toast.LENGTH_LONG).show();
//            }
//        });
//
//
//
//    }
//}
