package com.example.admin.sdnegga;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;


/**
 * A simple {@link Fragment} subclass.
 */
public class AvailableFragment_Buyer extends Fragment {




    private FirebaseUser mCurrentUser;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference propertiesRef=db.collection("Property");
    private CollectionReference usersRef=db.collection("Customer");
    private static final String FIRE_LOG = "Fire_Log";



    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {


        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String current_id = mCurrentUser.getUid();

        final View rootView = inflater.inflate(R.layout.fragment_available_buyer, container, false);
        //inflate and store in rootview

        final LinearLayout property_list_buyer=(LinearLayout) rootView.findViewById(R.id.property_list_buyer);
        //now initialize linear layout which is in rootview in  available_fragment_buyer .  id property_list_buyer is the id of fragment_available_buyer xml file.

        // retrieving the property whose "Property_status"(coloumn) is "Not_Rented"(value)
        propertiesRef.
                get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {



                for(QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){


                    //retrieving propertyID(Document) whose Property_Status(column) is "Not Rented"(value)
                    Property property=documentSnapshot.toObject(Property.class);
                    String property_id=documentSnapshot.getId();

                    //retrieving the ownerID from "Owner_id"(column) whose Property_Status is "Not Rented"
                    final String owner_id=property.getOwner_id();
                    String status = property.getProperty_Status();

                    if(status.equals("Not Rented") || status.equals("Negotiating")) {

                        //Retrieving or show only those AVAILABLE properties which are not owned by current logged in user.
                        if (!owner_id.equals(current_id)) {

                            final String name = property.getProperty_Name();
                            String address = property.getProperty_Address();
                            String desc = property.getProperty_Description();
                            String price = property.getProperty_Base_Price();
                            String pstatus = property.getProperty_Status();


                            final View Card = inflater.inflate(R.layout.activity_property_card_buyer, container, false);
                            final Button neg = (Button) Card.findViewById(R.id.neg_start);
                            final TextView p_id = (TextView) Card.findViewById(R.id.p_id);
                            final TextView p_name = (TextView) Card.findViewById(R.id.p_name);
                            final TextView p_address = (TextView) Card.findViewById(R.id.p_address);
                            final TextView p_desc = (TextView) Card.findViewById(R.id.p_desc);
                            final TextView p_price = (TextView) Card.findViewById(R.id.p_price);
                            final TextView p_owner = (TextView) Card.findViewById(R.id.p_owner);
                            final TextView p_status = (TextView) Card.findViewById(R.id.p_status);
                            final Button viewbtn = (Button)Card.findViewById(R.id.prop_img_btn) ;
                            final Button owner_details=(Button)Card.findViewById(R.id.owner_details);
                            final String image = documentSnapshot.getString("image");


                            usersRef.document(owner_id).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task <DocumentSnapshot> task) {
                                    if (task.isSuccessful()) {
                                        DocumentSnapshot documentSnapshot = task.getResult();

                                        if (documentSnapshot.exists() && documentSnapshot != null) {


                                            p_owner.setText(documentSnapshot.getString("Name"));

                                        }

                                    } else {
                                        Log.d(FIRE_LOG, "Error: " + task.getException().getMessage());
                                    }
                                }
                            });


                            p_id.setText(property_id);
                            p_name.setText(name);
                            p_address.setText(address);
                            p_desc.setText(desc);
                            p_price.setText(price);
                            p_status.setText(pstatus);

                            property_list_buyer.addView(Card);


                            viewbtn.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //retrieve image

                                    Intent intent= new Intent(getContext(),zoom_user_image.class);
                                    intent.putExtra("zoomimg",image);
                                    startActivity(intent);
                                    //overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                                }
                            });

                            neg.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(getContext(), BuyerNegoForm.class);
                                    intent.putExtra("pid", p_id.getText().toString());
                                    intent.putExtra("oid", owner_id);
                                    intent.putExtra("cid", current_id);
                                    intent.putExtra("pname", name);
                                    startActivity(intent);


                                }


                            });

                            owner_details.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(getContext(), ShowOwnerDetailsActivity.class);
                                    intent.putExtra("oid", owner_id);
                                    startActivity(intent);


                                }


                            });


                        }

                    }



                }








            }
        });

        return rootView;





    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            getFragmentManager().beginTransaction().detach(this).attach(this).commit();
            Log.i("IsRefresh", "Yes");
        }
    }



}
