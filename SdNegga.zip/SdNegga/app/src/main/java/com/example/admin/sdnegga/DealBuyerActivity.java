package com.example.admin.sdnegga;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class DealBuyerActivity extends AppCompatActivity {

    private FirebaseUser mCurrentUser;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference negotiateref=db.collection("Negotiate");
    private CollectionReference questionref=db.collection("Questions");
    private CollectionReference propertiesRef=db.collection("Property");

     private String buyer_status="";
     private String seller_status="";
     private String prop_id="";
     private String cust_id="";


    String buyer_has_clicked="";
    String curr_status_seller="";







    private static final String FIRE_LOG = "Fire_Log";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal_buyer);

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        final String sid = mCurrentUser.getUid();

        final String negid=getIntent().getExtras().getString("negid");

        //creates variable inflator of type layoutinflator ... code is same
        final LayoutInflater inflator = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        // grabs id of linear layout in scroll view
        final LinearLayout deal_list_buyer=(LinearLayout)findViewById(R.id.deal_list_buyer);

        final Button deal_buyer=(Button)findViewById(R.id.buyer_deal);
        final Button nodeal_buyer=(Button)findViewById(R.id.buyer_nodeal);

        final TextView curr_status_seller_tv=(TextView)findViewById(R.id.seller_status);








        negotiateref.document(negid).collection("final_questions").
                get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {



                for(final QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots){



                    View Card=inflator.inflate(R.layout.activity_deal_questions_list_buyer,null,false);
                    final TextView question_name=(TextView)Card.findViewById(R.id.question);
                    final EditText ans_buyer =(EditText)Card.findViewById(R.id.answer_buyer);
                    final EditText ans_seller =(EditText)Card.findViewById(R.id.answer_seller);
                    final TextView qid=(TextView)Card.findViewById(R.id.qid);
                    final Button submit_ans=(Button)Card.findViewById(R.id.submit_ans);
                    submit_ans.setClickable(true);









                    questionref.document(documentSnapshot.getId()).get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {

                            String question = documentSnapshot.getString("Question");
                            question_name.setText(question);


                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                        }
                    });


                    String buyans = documentSnapshot.getString("buyerans");
                    ans_buyer.setText(buyans);

                    String sellans = documentSnapshot.getString("sellerans");
                    ans_seller.setText(sellans);

                    qid.setText(documentSnapshot.getId());


                    submit_ans.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            AlertDialog.Builder builder = new AlertDialog.Builder(DealBuyerActivity.this);

                            builder.setTitle("Confirm");
                            builder.setMessage("Are you sure?");

                            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int which) {

                                    submit_ans.setClickable(false);
                                    String buyer_answer=ans_buyer.getText().toString();
                                    String q_id=qid.getText().toString();

                                    negotiateref.document(negid).collection("final_questions").document(q_id).update("buyerans", buyer_answer);
                                    Toast.makeText(DealBuyerActivity.this, "Answer Submitted Successfully", Toast.LENGTH_SHORT).show();


                                }
                            });

                            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    dialog.dismiss();
                                }
                            });

                            AlertDialog alert = builder.create();
                            alert.show();








                        }
                    });


                    deal_list_buyer.addView(Card);







                    negotiateref.document(negid).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task <DocumentSnapshot> task) {

                            DocumentSnapshot doc=task.getResult();

                            buyer_has_clicked=doc.getString("hasClicked_buyer");

                            curr_status_seller=doc.getString("seller_status");

                            curr_status_seller_tv.setText("The seller answer is: "+curr_status_seller);

                            if(buyer_has_clicked.equals("Yes"))

                            {

                                deal_buyer.setClickable(false);
                                nodeal_buyer.setClickable(false);

                                Toast.makeText(DealBuyerActivity.this, "You have already submitted your answer", Toast.LENGTH_LONG).show();



                            }
                            else
                            {
                                deal_buyer.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        AlertDialog.Builder builder = new AlertDialog.Builder(DealBuyerActivity.this);

                                        builder.setTitle("Accept this deal");
                                        builder.setMessage("Are you sure(Once decided, cannot be reverted)?");

                                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                                            public void onClick(DialogInterface dialog, int which) {

                                                negotiateref.document(negid).update(
                                                        "hasClicked_buyer", "Yes"
                                                );

                                                negotiateref.document(negid).update(
                                                        "buyer_status", "Yes"
                                                ).addOnSuccessListener(new OnSuccessListener <Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {

                                                        Toast.makeText(DealBuyerActivity.this, "Decision Submitted", Toast.LENGTH_SHORT).show();
                                                        negotiateref.document(negid).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task <DocumentSnapshot> task) {


                                                                DocumentSnapshot docSnapshot = task.getResult();

                                                                Toast.makeText(DealBuyerActivity.this, "negid" + docSnapshot, Toast.LENGTH_SHORT).show();


                                                                buyer_status = docSnapshot.getString("buyer_status");
                                                                seller_status = docSnapshot.getString("seller_status");
                                                                prop_id = docSnapshot.getString("PropertyID");
                                                                cust_id = docSnapshot.getString("CustomerID");


                                                                if (!seller_status.equals("")) {

                                                                    if (buyer_status.equals(seller_status)) {
                                                                        //Toast.makeText(DealBuyerActivity.this, "Fodo"+cust_id , Toast.LENGTH_LONG).show();
                                                                        propertiesRef.document(prop_id).update(
                                                                                "Property_Status", "Rented",
                                                                                "Customer_id", cust_id
                                                                        );

                                                                        negotiateref.document(negid).delete();
                                                                        Toast.makeText(DealBuyerActivity.this, "Congratulations, The deal is successful", Toast.LENGTH_LONG).show();

                                                                    } else {

                                                                        negotiateref.document(negid).delete();


                                                                        Toast.makeText(DealBuyerActivity.this, "The Deal is Unsuccessful/Pending/Rented out ", Toast.LENGTH_SHORT).show();

                                                                        negotiateref.
                                                                                get().addOnSuccessListener(new OnSuccessListener <QuerySnapshot>() {
                                                                            @Override
                                                                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {


                                                                                for (QueryDocumentSnapshot docsnap : queryDocumentSnapshots) {


                                                                                    String pid = docsnap.getString("PropertyID");
                                                                                    String negstatus = docsnap.getString("Neg_status");

                                                                                    if (prop_id.equals(pid) && negstatus.equals("Negotiating")) {

                                                                                        propertiesRef.document(pid).update(
                                                                                                "Property_Status", "Negotiating"

                                                                                        );

                                                                                    } else {
                                                                                        propertiesRef.document(pid).update(
                                                                                                "Property_Status", "Not Rented"


                                                                                        );
                                                                                        Toast.makeText(DealBuyerActivity.this, "Tu zb", Toast.LENGTH_LONG).show();


                                                                                    }

                                                                                }


                                                                            }
                                                                        });


                                                                    }


                                                                }


                                                            }
                                                        });

                                                    }
                                                }).addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {

                                                    }
                                                });


                                                deal_buyer.setClickable(false);
                                                nodeal_buyer.setClickable(false);


//                                    submit_ans.setClickable(false);
//                                    String seller_answer=ans_seller.getText().toString();
//                                    String q_id=qid.getText().toString();
//
//                                    negotiateref.document(negid).collection("final_questions").document(q_id).update("sellerans", seller_answer);
//                                    Toast.makeText(DealActivity.this, "Answer Submitted Successfully", Toast.LENGTH_SHORT).show();


                                            }
                                        });

                                        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                dialog.dismiss();
                                            }
                                        });

                                        AlertDialog alert = builder.create();
                                        alert.show();


                                    }
                                });


                                nodeal_buyer.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {

                                        AlertDialog.Builder builder = new AlertDialog.Builder(DealBuyerActivity.this);

                                        builder.setTitle("Reject this deal");
                                        builder.setMessage("Are you sure(Once decided, cannot be reverted)?");

                                        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                                            public void onClick(DialogInterface dialog, int which) {

                                                negotiateref.document(negid).update(
                                                        "hasClicked_buyer", "Yes"
                                                );

                                                negotiateref.document(negid).update(
                                                        "buyer_status", "No"
                                                ).addOnSuccessListener(new OnSuccessListener <Void>() {
                                                    @Override
                                                    public void onSuccess(Void aVoid) {

                                                        Toast.makeText(DealBuyerActivity.this, "Decision Submitted", Toast.LENGTH_SHORT).show();
                                                        negotiateref.document(negid).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task <DocumentSnapshot> task) {


                                                                DocumentSnapshot docSnapshot = task.getResult();

                                                                Toast.makeText(DealBuyerActivity.this, "negid" + docSnapshot, Toast.LENGTH_SHORT).show();


                                                                buyer_status = docSnapshot.getString("buyer_status");
                                                                seller_status = docSnapshot.getString("seller_status");
                                                                prop_id = docSnapshot.getString("PropertyID");
                                                                cust_id = docSnapshot.getString("CustomerID");


                                                                if (!seller_status.equals("")) {

                                                                    if (buyer_status.equals(seller_status) || !buyer_status.equals(seller_status)) {
                                                                        //Toast.makeText(DealBuyerActivity.this, "Fodo"+cust_id , Toast.LENGTH_LONG).show();


                                                                        negotiateref.document(negid).delete();
                                                                        Toast.makeText(DealBuyerActivity.this, "The Deal has Ended Unsuccessfully", Toast.LENGTH_LONG).show();
                                                                        negotiateref.
                                                                                get().addOnSuccessListener(new OnSuccessListener <QuerySnapshot>() {
                                                                            @Override
                                                                            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {


                                                                                for (QueryDocumentSnapshot docsnap : queryDocumentSnapshots) {


                                                                                    String pid = docsnap.getString("PropertyID");
                                                                                    String negstatus = docsnap.getString("Neg_status");

                                                                                    if (prop_id.equals(pid) && negstatus.equals("Negotiating")) {

                                                                                        propertiesRef.document(pid).update(
                                                                                                "Property_Status", "Negotiating"

                                                                                        );

                                                                                    } else {
                                                                                        propertiesRef.document(pid).update(
                                                                                                "Property_Status", "Not Rented"


                                                                                        );
                                                                                        Toast.makeText(DealBuyerActivity.this, "Tu zb", Toast.LENGTH_LONG).show();


                                                                                    }

                                                                                }


                                                                            }
                                                                        });


                                                                    }


                                                                }


                                                            }
                                                        });

                                                    }
                                                }).addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {

                                                    }
                                                });


                                                deal_buyer.setClickable(false);
                                                nodeal_buyer.setClickable(false);


//                                    submit_ans.setClickable(false);
//                                    String seller_answer=ans_seller.getText().toString();
//                                    String q_id=qid.getText().toString();
//
//                                    negotiateref.document(negid).collection("final_questions").document(q_id).update("sellerans", seller_answer);
//                                    Toast.makeText(DealActivity.this, "Answer Submitted Successfully", Toast.LENGTH_SHORT).show();


                                            }
                                        });

                                        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                                dialog.dismiss();
                                            }
                                        });

                                        AlertDialog alert = builder.create();
                                        alert.show();


                                    }
                                });
                            }
                        }
                    });





















//                    nodeal_buyer.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//
//                            AlertDialog.Builder builder = new AlertDialog.Builder(DealBuyerActivity.this);
//
//                            builder.setTitle("Reject this deal");
//                            builder.setMessage("Are you sure(Once decided, cannot be reverted)?");
//
//                            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
//
//                                public void onClick(DialogInterface dialog, int which) {
//
//                                    negotiateref.document(negid).update(
//                                            "buyer_status","No"
//                                    ).addOnSuccessListener(new OnSuccessListener <Void>() {
//                                        @Override
//                                        public void onSuccess(Void aVoid) {
//
//                                            Toast.makeText(DealBuyerActivity.this,"Decision Submitted",Toast.LENGTH_SHORT).show();
//                                            negotiateref.document(negid).get().addOnCompleteListener(new OnCompleteListener <DocumentSnapshot>() {
//                                                @Override
//                                                public void onComplete(@NonNull Task <DocumentSnapshot> task) {
//
//
//
//                                                    DocumentSnapshot docSnapshot = task.getResult();
//
//                                                    Toast.makeText(DealBuyerActivity.this, "negid"+docSnapshot, Toast.LENGTH_SHORT).show();
//
//
//                                                    buyer_status = docSnapshot.getString("buyer_status");
//                                                    seller_status = docSnapshot.getString("seller_status");
//                                                    prop_id = docSnapshot.getString("PropertyID");
//                                                    cust_id = docSnapshot.getString("CustomerID");
//
//
//                                                    if(!buyer_status.equals("")) {
//
//                                                        if (buyer_status.equals(seller_status)) {
//                                                            //Toast.makeText(DealBuyerActivity.this, "Fodo"+cust_id , Toast.LENGTH_LONG).show();
//                                                            propertiesRef.document(prop_id).update(
//                                                                    "Property_Status", "Not Rented"
//                                                            );
//
//                                                            negotiateref.document(negid).update(
//                                                                    "Neg_status", "Failed"
//                                                            );
//                                                            Toast.makeText(DealBuyerActivity.this, "Deal has been Cancelled", Toast.LENGTH_SHORT).show();
//
//                                                        }
//                                                        else{
//
//                                                            Toast.makeText(DealBuyerActivity.this, "The Deal is Unsuccessful or Pending", Toast.LENGTH_SHORT).show();
//
//                                                        }
//
//
//                                                    }
//
//
//
//                                                }
//                                            });
//
//                                        }
//                                    }).addOnFailureListener(new OnFailureListener() {
//                                        @Override
//                                        public void onFailure(@NonNull Exception e) {
//
//                                        }
//                                    });
//
//
//
//
//
//                                    nodeal_buyer.setClickable(false);
//
//
//
//
////                                    submit_ans.setClickable(false);
////                                    String seller_answer=ans_seller.getText().toString();
////                                    String q_id=qid.getText().toString();
////
////                                    negotiateref.document(negid).collection("final_questions").document(q_id).update("sellerans", seller_answer);
////                                    Toast.makeText(DealActivity.this, "Answer Submitted Successfully", Toast.LENGTH_SHORT).show();
//
//
//                                }
//                            });
//
//                            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
//
//                                @Override
//                                public void onClick(DialogInterface dialog, int which) {
//
//                                    dialog.dismiss();
//                                }
//                            });
//
//                            AlertDialog alert = builder.create();
//                            alert.show();
//
//
//
//
//
//
//
//
//                        }
//                    });






                }

            }
        });

    }
}
