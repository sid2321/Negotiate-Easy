package com.example.admin.sdnegga;

class Negotiate {




    private String ID;
    private String SellerID;
    private String CustomerID;
    private String PropertyID;
    private String Property_Name;
    private String Status;

    public Negotiate() {
    }

    public Negotiate(String sellerid,String customerid, String propertyid,String status){
        SellerID=sellerid;
        CustomerID=customerid;
        PropertyID=propertyid;
        Status=status;

    }

    public String getSellerID() {
        return SellerID;
    }

    public void setSellerID(String sellerID) {
        SellerID = sellerID;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String customerID) {
        CustomerID = customerID;
    }

    public String getPropertyID() {
        return PropertyID;
    }

    public void setPropertyID(String propertyID) {
        PropertyID = propertyID;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getProperty_Name() {
        return Property_Name;
    }

    public void setProperty_Name(String property_Name) {
        Property_Name = property_Name;
    }
}
